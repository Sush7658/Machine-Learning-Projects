# Machine-Learning-Projects
This Repository includes basic machine learning projects for beginners

Model used :

Project 1: Rock vs Mine Prediction : Logistic Regression

Project 2: Fake News Prediction    : Logistic Regression

Project 3: Diabetes Prediction   : Support Vector Machine

Project 4: House Prediction : XGBoost Regressor

Project 5: Loan Status Prediction   : Support Vector Machine

Project 6: Wine Quality Prediction : Random Forest Classifier

Project 7: Car Price Prediction : Linear and Lasso Regression

Project 8: Gold Price Prediction : Random Forest Regressor

Project 9: Heart Disease Prediction : Logistic Regression

Project 10: Credit Card Fraud Detection : Logistic Regression

Project 11: Medical insurance Cost Prediction : Linear Regression

Project 12: Big Mart Sales Prediction : XGBoost Regressor

Project 13: Customer Segmentation : K-Means Clustering

Project 14: Parkinson's Disease Prediction   : Support Vector Machine

Project 15: Titanic Survival Prediction : Logistic Regression

Project 16: Calories Burnt Prediction : XGBoost Regressor

Project 17: Movies Recommendation System : Cosine Similarity
